import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;


class form2 extends JFrame implements ActionListener
{


	JLabel l1,l2,l3,l4;
	JTextField t1,t2,t3; 
	JButton b1,b2;

	public form2()
		{
			setVisible(true);
			setBounds(0,0,2200,1500);
			setTitle("Register Room");
			setLayout(null);
				//Labels
			l1=new JLabel("Register Room");
			l2=new JLabel("Room Number");
			l3=new JLabel("Room Capacity");
			l4=new JLabel("Room Count");
			//textfields to take input
			t1=new JTextField();	
			t2=new JTextField();
			t3=new JTextField();
			//buttons to submit the records
			b1=new JButton("Submit");
			b2=new JButton("Home");
			//actionlistenner implementing 
			b1.addActionListener(this);
			b2.addActionListener(this);

								//setbounds to design the specific place for the object
										//title
										l1.setBounds(150,50,300,60);

			//Room Number				
			l2.setBounds(50,100,150,40);			t1.setBounds(200,100,200,40);

			//Room capacity
			l3.setBounds(50,150,150,40);			t2.setBounds(200,150,200,40);

			//room count																													
			l4.setBounds(50,200,150,40);			t3.setBounds(200,200,150,40);		
			
			//Submit								//Cancel
			b1.setBounds(50,250,200,40);			b2.setBounds(270,250,200,40);
			
			add(l1);add(l2);add(l3);add(l4);
			add(t1);add(t2);add(t3);
			add (b1);add(b2);
			

					
		}
		public void actionPerformed(ActionEvent ae)
		{
				if(ae.getSource()==b2)
					{
						new home();
						setVisible(false);
					}
				if(ae.getSource()==b1)
				{
					try
					{
						String a="'"+t1.getText()+"'";
						String b="'"+t2.getText()+"'";
						String c="'"+t3.getText()+"'";
					
					//step1 Specify driver
						Class.forName("com.mysql.jdbc.Driver");

					//step2 Create connection
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");

					//step 3
						Statement st=con.createStatement();
						st.executeUpdate("INSERT INTO roomregister (room_number,room_capacity,room_count) VALUES (" + a + "," + b + ","+ c +")");

						st.close();
						con.close();
						Frame f1=new Frame();
						JOptionPane.showMessageDialog(f1,"Room Created Succesfully");
						setVisible(false);
					}
					catch(Exception e)
					{
						System.out.println(e);
						Frame f2=new Frame();
						JOptionPane.showMessageDialog(f2,"Error!! Please try again");
					}
				}
			}
}
class roomregisterform
{
	public static void main(String cp[])
	{
		form2 f2=new form2();
	}
}