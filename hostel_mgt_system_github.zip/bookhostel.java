import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;

class form6 extends JFrame implements ActionListener
{


	JLabel l1,l2,l3,l4,l5,l6;
	JTextField t1,t2,t3,t4; 
	JButton b1,b2,b3;
	JComboBox c1;

	public form6()
		{
			

			setVisible(true);
			setBounds(0,0,2200,1500);
			setTitle("Book hostel");
			setLayout(null);
			Vector<Integer> v=new Vector<Integer>();
					
			try
					{
					
					//step1 Specify driver
						Class.forName("com.mysql.jdbc.Driver");

					//step2 Create connection
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");

						//step 3
						Statement st=con.createStatement();
						ResultSet rs=st.executeQuery("select room_id from roomregister");
						while(rs.next())
						{
							v.add(rs.getInt(1));
						}
						st.close();
						con.close();
						//setVisible(false);
					}
					catch(Exception e)
					{
						System.out.println(e);
						Frame f2=new Frame();
						JOptionPane.showMessageDialog(f2,"Error!! Please try again");
					}
				//Labels
			l1=new JLabel("Book Hostel");
			l2=new JLabel("Room");
			l3=new JLabel("Unoccupied");
			l4=new JLabel("Student id");
			l5=new JLabel("Full name");
			l6=new JLabel("Fees");
			c1=new JComboBox(v);	
			t1=new JTextField();
			t2=new JTextField();
			t3=new JTextField();
			t4=new JTextField();
			//buttons to submit the records
			b1=new JButton("Verify");
			b2=new JButton("Submit");
			b3=new JButton("Home");
			//actionlistenner implementing 
			b1.addActionListener(this);
			b2.addActionListener(this);
			b3.addActionListener(this);


////////////////incomplet frm here
								//setbounds to design the specific place for the object
										//title
										l1.setBounds(150,50,300,60);										
																								

			//Room 								 
			l2.setBounds(50,150,150,40);			c1.setBounds(150,150,200,40);  				b1.setBounds(370,150,150,40);			

			//unoccupied																													
			l3.setBounds(50,200,150,40);			t1.setBounds(150,200,150,40);		
			
			//student id								
			l4.setBounds(50,250,200,40);			t2.setBounds(150,250,150,40);

			//fullname
			l5.setBounds(50,300,200,40);			t3.setBounds(150,300,150,40);

			//fees
			l6.setBounds(50,350,200,40);			t4.setBounds(150,350,150,40);

            //Submit								//Cancel
			b2.setBounds(50,400,200,40);			b3.setBounds(270,400,200,40);
			

			
			add(l1);add(l2);add(l3);add(l4);add(l5);add(l6);
			add(t1);add(t2);add(t3);add(t4);
			add (b1);add(b2);add(b3);
			add(c1);
			

					
		}
		public void actionPerformed(ActionEvent ae)
		{		if(ae.getSource()==b3)
					{
					new home();
					setVisible(false);
					}
				if(ae.getSource()==b1)
				{
					int rid=(Integer)c1.getSelectedItem();
					try
					{
					
					//step1 Specify driver
						Class.forName("com.mysql.jdbc.Driver");

					//step2 Create connection
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");

						//step 3
						Statement st=con.createStatement();
						ResultSet rs=st.executeQuery("select room_capacity,room_count from roomregister where room_id="+rid+"");
						rs.next();
						int a=rs.getInt(1);
						int b=rs.getInt(2);
						int c=a-b;
						t1.setText(c+"");
						rs.close();
						st.close();
						con.close();
						//setVisible(false);
					}
					
					catch(Exception e)
					{
						System.out.println(e);
						Frame f2=new Frame();
						JOptionPane.showMessageDialog(f2,"Error!! Please try again");
					}
					
				}

				if(ae.getSource()==b2)
				{
					try
					{
						String b="'"+t2.getText()+"'";
						String c="'"+t3.getText()+"'";
						String a="'"+t4.getText()+"'";
						int rid=(Integer)c1.getSelectedItem();
					//step1 Specify driver
						Class.forName("com.mysql.jdbc.Driver");

					//step2 Create connection
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");

					//step 3
						Statement st=con.createStatement();
						st.executeUpdate("INSERT INTO room_allotment (room_id,stud_id,full_name,fees) VALUES ("+rid+","+b+","+c+","+a+")");
						Statement st1=con.createStatement();
						st1.executeUpdate("update roomregister set room_count=room_count+1 where room_id="+rid+"");
						st1.close();
						st.close();
						con.close();

						Frame f1=new Frame();
						JOptionPane.showMessageDialog(f1,"Room Created Succesfully");
						setVisible(false);
					}

					catch(Exception e)
					{
						System.out.println(e);
						Frame f2=new Frame();
						JOptionPane.showMessageDialog(f2,"Error!! Please try again");
					}
				}
			}
	}

class bookhostel
{
	public static void main(String cp[])
	{
		form6 f6=new form6();
	}
}