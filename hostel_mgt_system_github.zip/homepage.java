import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class home extends JFrame implements ActionListener
{
	JLabel lb1;
	JButton b1,b2,b3,b4,b5,b6,b7,b8;
	public home()
		{
			setLayout(null);
			lb1=new JLabel("Homepage");
			//Homepage Contents
			b1= new JButton("Student Registration");
			b2= new JButton("Room Registration");
			b3= new JButton("Room History");
			b4= new JButton("Maintainence");
			b5= new JButton("Students List");
			b6= new JButton("Book Hostel");
			b7= new JButton("About us");
			b8=new JButton("Maintainence History");
			
			lb1.setBounds(400,10,100,110);
			b1.setBounds(50,100,160,110);
			b2.setBounds(250,100,160,110);
			b6.setBounds(450,100,160,110);
			b5.setBounds(50,230,160,110);
			b3.setBounds(250,230,160,110);
			b4.setBounds(450,230,160,110);
			b7.setBounds(650,230,160,110);
			b8.setBounds(650,100,160,110);
		


			
			b1.addActionListener(this);
			b2.addActionListener(this);
			b3.addActionListener(this);
			b4.addActionListener(this);
			b5.addActionListener(this);
			b6.addActionListener(this);
			b7.addActionListener(this);
			b8.addActionListener(this);
			
			add(lb1);
			add(b1);
			add(b2);
			add(b3);
			add(b4);
			add(b5);
			add(b6);
			add(b7);
			add(b8);
			
			setTitle("Homepage");
			setVisible(true);
			setBounds(0,0,2200,1500);
		}
		public void actionPerformed(ActionEvent ae)
		{
				//if user selects button 1 i.e. student registration button
				if(ae.getSource()==b1)
				{
					try
					{	new form1();
						setVisible(false);
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				}

				//if user selects button 2 i.e. room registration
				if(ae.getSource()==b2)
				{
					try
					{	new form2();
						setVisible(false);
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				}

				//if user selects button 3 i.e. Room history 
				if(ae.getSource()==b3)
				{
					try
					{	new form3();
						setVisible(false);
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				}
				//if user selects button 4 i.e.maintenance
				if(ae.getSource()==b4)
				{
					try
					{	new form4();
						setVisible(false);
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				}

				//if user selects button 5 i.e. Students list
				if(ae.getSource()==b5)
				{
					try
					{	new form5();
						setVisible(false);
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				}

				//if user selects button 6 i.e. book hostel
				if(ae.getSource()==b6)
				{
					try
					{	new form6();
						setVisible(false);
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				}

				if(ae.getSource()==b7)
				{
					try
					{	new form7();
						setVisible(false);
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				}


				//if user selects button 8 i.e. maintenance history
				if(ae.getSource()==b8)
				{
					try
					{	new form8();
						setVisible(false);
					}
					catch(Exception e)
					{
						System.out.println(e);
					}
				}

				

}
}
class homepage
{
	public static void main(String cp[])
	{
		new home();
	}
}