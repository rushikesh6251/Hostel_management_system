	import javax.swing.*;
	import java.awt.*;
	import java.awt.event.*;
	import java.sql.*;


	class form4 extends JFrame implements ActionListener
	{


		JLabel l1,l2,l3,l4;
		JTextField t1,t2,t3; 
		JButton b1,b2;

		public form4()
			{
				setVisible(true);
				setBounds(0,0,2200,1500);
				setTitle("Maintenance");
				setLayout(null);
					//Labels
				l1=new JLabel("Maintenance");
				l2=new JLabel("Maintainence");
				l3=new JLabel("Person Responsible");
				l4=new JLabel("Amount");
				//textfields to take input
				t1=new JTextField();	
				t2=new JTextField();
				t3=new JTextField();
				//buttons to submit the records
				b2=new JButton("Submit");
				b1=new JButton("Home");
				//actionlistenner implementing 
				b1.addActionListener(this);
				b2.addActionListener(this);

									//setbounds to design the specific place for the object
											//title
											l1.setBounds(150,100,300,60);

				//Maintenance				
				l2.setBounds(50,150,150,40);			t1.setBounds(200,150,300,80);

				//Person Responsible
				l3.setBounds(50,250,150,40);			t2.setBounds(200,250,200,40);

				//Amount																													
				l4.setBounds(50,300,150,40);			t3.setBounds(200,300,150,40);		
				
				//Submit								//Cancel
				b2.setBounds(50,370,200,40);			b1.setBounds(270,370,200,40);
				
				add(l1);add(l2);add(l3);add(l4);
				add(t1);add(t2);add(t3);
				add (b1);add(b2);
				

						
			}
			public void actionPerformed(ActionEvent ae)
			{
					if(ae.getSource()==b1)
						{
						new home();
						setVisible(false);
						}
					if(ae.getSource()==b2)	
					{
						try
						{
							String a="'"+t1.getText()+"'";
							String b="'"+t2.getText()+"'";
							String c="'"+t3.getText()+"'";
						
						//step1 Specify driver
							Class.forName("com.mysql.jdbc.Driver");

						//step2 Create connection
							Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");

						//step 3
							Statement st=con.createStatement();
							st.executeUpdate("INSERT INTO maintenance (m_description,person_responsible,amount) VALUES (" + a + "," + b + ","+ c +")");

							st.close();
							con.close();
							Frame f1=new Frame();
							JOptionPane.showMessageDialog(f1,"Data entered sucessfully");
							setVisible(false);
						}
						catch(Exception e)
						{
							System.out.println(e);
							Frame f2=new Frame();
							JOptionPane.showMessageDialog(f2,"Error!! Please try again");
						}
					}
				}
	}
	class maintenance
	{
		public static void main(String cp[])
		{
			form4 f4=new form4();
		}
	}