-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2024 at 08:18 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 5.6.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('rushikesh', 'arpita');

-- --------------------------------------------------------

--
-- Table structure for table `maintenance`
--

CREATE TABLE `maintenance` (
  `m_id` int(11) NOT NULL,
  `m_description` varchar(200) NOT NULL,
  `person_responsible` varchar(200) NOT NULL,
  `amount` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maintenance`
--

INSERT INTO `maintenance` (`m_id`, `m_description`, `person_responsible`, `amount`) VALUES
(1, 'fire', 'dfghjk', '456789'),
(2, '', '', ''),
(3, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `roomregister`
--

CREATE TABLE `roomregister` (
  `room_id` int(11) NOT NULL,
  `room_number` varchar(200) NOT NULL,
  `room_capacity` varchar(200) NOT NULL,
  `room_count` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roomregister`
--

INSERT INTO `roomregister` (`room_id`, `room_number`, `room_capacity`, `room_count`) VALUES
(2, 'R1', '4', '2'),
(3, 'R2', '4', '0'),
(4, 'R3', '4', '0'),
(5, 'R4', '4', '0'),
(6, 'R5', '4', '0'),
(7, 'R6', '4', '0'),
(8, 'R7', '4', '0'),
(9, 'R8', '4', '0'),
(20, 'R9', '3', '0'),
(21, 'R10', '4', '0'),
(22, 'R11', '3', '0'),
(23, 'R12', '4', '0'),
(24, 'R13', '3', '0'),
(25, 'R14', '4', '0'),
(26, 'R15', '3', '0'),
(27, 'R16', '4', '0'),
(28, 'R17', '3', '0'),
(29, 'R18', '4', '0'),
(30, 'R19', '3', '0'),
(31, 'R20', '4', '0');

-- --------------------------------------------------------

--
-- Table structure for table `room_allotment`
--

CREATE TABLE `room_allotment` (
  `room_id` varchar(200) NOT NULL,
  `stud_id` varchar(200) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `fees` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room_allotment`
--

INSERT INTO `room_allotment` (`room_id`, `stud_id`, `full_name`, `fees`) VALUES
('2', '4', 'Meghraj Hemant Chavan', 20000),
('2', '5', 'Rohit Mahendra Salunke', 20000);

-- --------------------------------------------------------

--
-- Table structure for table `student_register`
--

CREATE TABLE `student_register` (
  `studid` int(11) NOT NULL,
  `full_name` varchar(200) NOT NULL,
  `home_address` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `pincode` varchar(200) NOT NULL,
  `personal_phone` varchar(200) NOT NULL,
  `email_id` varchar(200) NOT NULL,
  `dob` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `date_of_arrival` varchar(200) NOT NULL,
  `course` varchar(200) NOT NULL,
  `year` varchar(200) NOT NULL,
  `fathername` varchar(200) NOT NULL,
  `occupation` varchar(200) NOT NULL,
  `father_phone` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_register`
--

INSERT INTO `student_register` (`studid`, `full_name`, `home_address`, `city`, `state`, `pincode`, `personal_phone`, `email_id`, `dob`, `gender`, `date_of_arrival`, `course`, `year`, `fathername`, `occupation`, `father_phone`) VALUES
(1, 'Saket Gokhale', 'A-87 marine complex, west malad mumbai', 'Malad', 'Maharashtra', '412000', '1234567890', 'example@gmail.com', '15/01/2003', 'Male', '14/05/2023', 'BCA', '1st', 'santosh gokhale', 'job', '09876543212'),
(2, 'Arpita  Upendra Murumkar', 'Shejal House 2341 santosh nagar solapur', 'solapur', 'maharashtra', '413001', '9876541234', 'arpitamurumkar@gmail,com', '20/03/2003', 'Female', '01/01/2023', 'Bca', '3', 'Upendra Murumkar', 'Accountant', '9846213457'),
(4, 'Meghraj Hemant Chavan ', 'Ruby nagar D32 solapur ', 'solapur', 'Maharashtra', '413006', '9867543245', 'megh143@gmail.com', '10/08/2003', 'Male', '12/02/2023', 'Bca', '3', 'Hemant Chavan', 'job', '8767980654'),
(5, 'Rohit Mahendra Salunke', 'pune naka s234 solapur', 'solapur', 'Maharashtra', '413008', '7689054321', 'rohuuS12@gmail.com', '12/04/2003', 'Male', '01/09/2023', 'Bca', '3', 'Mahendra Salunke', 'buisness', '9087675434'),
(6, 'Vaibhav Phatate', 'near Market yard santosh nagar e435 solapur', 'solapur', 'maharashtra', '413008', '8976689708', 'vaibhav321@gmail.com', '20/07/2003', 'Male', '10/08/2023', 'Bca', '3', 'siddharth phatate', 'buisness', '897656467'),
(7, 'Arbiya Haider Mujawar', 'santosh nagar murum', 'Murum', 'Maharashtra', '411230', '7689574789', 'arbiyayz@gmail.com', '03/11/2003', 'Female', '26/03/2023', 'bca', '2', 'haider mujawar', 'teacher', '8978876756'),
(8, 'Amit Kumar', '123 Gali No. 5', 'Delhi', 'Delhi', '110001', '91-9876543210', 'amitkumar@email.com', '18/11/2003', 'Male', '18/02/2023', 'Bca', '3', 'Rajesh Kumar', 'Engineer', '91-8765432109'),
(9, 'Priya Patel', '456 Shanti Vihar', 'Mumbai', 'Maharashtra', '400001', '91-9876543211', 'priyapatel@email.com', '25/07/2003', 'Female', '05/10/2023', 'Bba', '3', 'Neha Patel', 'Teacher', '91-8765432108'),
(10, 'Rahul Sharma', '789 Subhash Nagar', 'Bangalore', 'Karnataka', '560001', '91-9876543212', 'rahulsharma@email.com', '07/09/2003', 'Male', '25/03/2023', 'Mca', '2', 'Suresh Sharma', 'Accountant', '91-8765432107'),
(11, 'Neha Gupta', '101 Rajaji Nagar', 'Chennai', 'Tamil Nadu', '600001', '91-9876543213', 'nehagupta@email.com', '02/12/2003', 'Female', '15/06/2023', 'Mba', '3', 'Rajesh Gupta', 'Doctor', '91-8765432106'),
(12, 'Vikram Singh', '202 Gandhi Road', 'Kolkata', 'West Bengal', '700001', '91-9876543214', 'vikramsingh@email.com', '14/06/2003', 'Male', '12/10/2023', 'Bca', '3', 'Ramesh Singh', 'Engineer', '91-8765432105'),
(13, 'Anita Verma', '303 Patel Colony', 'Ahmedabad', 'Gujarat', '380001', '91-9876543215', 'anitaverma@email.com', '26/10/2003', 'Female', '27/02/2023', 'Bba', '3', 'Rajesh Verma', 'Marketing Manager', '91-8765432104'),
(14, 'Rajeev Joshi', '404 Gandhi Chowk', 'Pune', 'Maharashtra', '411001', '91-9876543216', 'rajeevjoshi@email.com', '30/07/2003', 'Male', '12/01/2023', 'Chemistry', '1', 'Sudhir Joshi', 'Chemist', '91-8765432103'),
(15, 'Sneha Desai', '505 Swami Nagar', 'Hyderabad', 'Telangana', '500001', '91-9876543217', 'snehadesai@email.com', '19/05/2003', 'Female', '28/06/2023', 'English Literature', '1', 'Ramesh Desai', 'Writer', '91-8765432102'),
(16, 'Alok Singhania', '606 Rajmahal Road', 'Jaipur', 'Rajasthan', '302001', '91-9876543218', 'aloksinghania@email.com', '08/09/2003', 'Male', '03/10/2023', 'History', '1', 'Rajendra Singhania', 'Historian', '91-8765432101'),
(17, 'Rina Kapoor', '707 Prasad Enclave', 'Lucknow', 'Uttar Pradesh', '226001', '91-9876543219', 'rinakapoor@email.com', '01/03/2003', 'Female', '21/09/2023', 'Computer Engineering', '2', 'Suresh Kapoor', 'Software Engineer', '91-8765432100'),
(18, 'Sunita Reddy', '808 Green Park', 'Chennai', 'Tamil Nadu', '600020', '91-9876543227', 'sunitareddy@email.com', '04/07/2003', 'Female', '18/07/2023', 'Bca', '1', 'Ramesh Reddy', 'Engineer', '91-8765432107'),
(19, 'Ajay Verma', '1021 Shanti Nagar', 'Mumbai', 'Maharashtra', '400012', '91-9876543228', 'ajayverma@email.com', '21/02/2003', 'Male', '23/07/2023', 'Bba', '2', 'Suresh Verma', 'Accountant', '91-8765432108'),
(20, 'Nisha Sharma', '450 Jubilee Hills', 'Hyderabad', 'Telangana', '500033', '91-9876543229', 'nishasharma@email.com', '22/08/2003', 'Female', '11/05/2023', 'Mca', '2', 'Rajesh Sharma', 'Teacher', '91-8765432109'),
(21, 'Rohit Gupta', '701 Ashok Vihar', 'Delhi', 'Delhi', '110025', '91-9876543230', 'rohitgupta@email.com', '29/09/2003', 'Male', '14/02/2023', 'Mba', '3', 'Sanjay Gupta', 'Doctor', '91-8765432110');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `maintenance`
--
ALTER TABLE `maintenance`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `roomregister`
--
ALTER TABLE `roomregister`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `student_register`
--
ALTER TABLE `student_register`
  ADD PRIMARY KEY (`studid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `maintenance`
--
ALTER TABLE `maintenance`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `roomregister`
--
ALTER TABLE `roomregister`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `student_register`
--
ALTER TABLE `student_register`
  MODIFY `studid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
