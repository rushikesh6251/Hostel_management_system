		import javax.swing.*;
		import java.awt.event.*;
		import java.util.*;
		import java.sql.*;
		import java.awt.*;
		import javax.swing.table.*;

		class form3 extends JFrame implements ActionListener
		{
			JLabel lb1,lb2;
			JButton b1,b2;
			JComboBox cb1;
			Connection con;
			Statement st;
			ResultSet rs1;
			String ids;
			static JTable table;
		  String sub="";
			String[] columnnames={"Room ID","Student Id","Full name","Fees"};
			String from;
			JFrame frame1;
			public form3()
			{
				lb1=new JLabel("Fetching Room History");
				lb1.setForeground(Color.RED);
				lb1.setFont(new Font("Comic Sans MS",Font.BOLD,22));

				lb2=new JLabel("Room ID");

				b1=new JButton("Home");
				b2=new JButton("Submit");

				lb1.setBounds(100,50,350,40);
		    lb2.setBounds(75,110,150,40);
				b1.setBounds(200,200,150,40);
				b2.setBounds(40,200,150,40);

			  b1.addActionListener(this);
				b2.addActionListener(this);

			  setTitle("Room History Report");
				setLayout(null);
			  setVisible(true);
			  setBounds(0,0,2200,1500);

			  setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		    add(lb1); add(lb2);
			  add(b1); add(b2);
				
		    try
				{
					Class.forName("com.mysql.jdbc.Driver");
		                                  
					con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");
		                                  
					st=con.createStatement();
					
					rs1=st.executeQuery("select distinct(room_id) from roomregister");
		      if(rs1==null)
		      System.out.println("null");
		                                  
					Vector v=new Vector();
		                                  
					while(rs1.next())
					{                          
		      	ids=rs1.getString("room_id");
						v.add(ids);	
		      }
		      cb1 =new JComboBox(v);
					cb1.setBounds(175,110,150,50);
					add(cb1);
					st.close();
					rs1.close();
		    }
		    catch(Exception e)
		    {
		    	System.out.println(e);
		    } 
		  }
		public void actionPerformed(ActionEvent ae)
			{
		      if(ae.getSource()==b2)
					showTableData();

					if(ae.getSource()==b1)
					{
						new home();
						setVisible(false);
					}
				}
				public void showTableData()
				{
				  frame1=new JFrame("Room History Report");
				  frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		      frame1.setLayout(new BorderLayout());
				  DefaultTableModel model=new  DefaultTableModel();
				  model.setColumnIdentifiers(columnnames);
				  table = new JTable();
				  table.setModel(model);
				  table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
				  JScrollPane scroll = new JScrollPane(table);
				  scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				  scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		      from = (String)cb1.getSelectedItem();
					int cid,bill;
					String cname,bdate;
				  try
				  {
				   PreparedStatement pst=con.prepareStatement("select * from roomregister where room_id='"+from+"' " );
			     ResultSet rs=pst.executeQuery();

				   	int i=0;
				 		String fn,pe,lv,pk,fs,pc,ib;
		        fn=from;
		        int g,d;
		        String a,b,c,e,f;
				   while(rs.next())
				   {
		          a=rs.getString(1);
		          b=rs.getString(2);
		       		c=rs.getString(3);
		          d=rs.getInt(4);
		          
				      model.addRow(new Object[]{a,b,c,d});		
				      i++;			      

		        	}	 
		          if(i<1)
				      JOptionPane.showMessageDialog(null,"No Record Found","Error",JOptionPane.ERROR_MESSAGE);

		        }catch(Exception e)
		        {
		          JOptionPane.showMessageDialog(null,e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
		        }
		           frame1.add(scroll);
				       frame1.setVisible(true);
				       frame1.setSize(1366,768); 	
						}
		}
		class roomhistory
		{
		  public static void main(String cp[])
		  {
		      form3 f3=new form3();
		    }
		}