import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;


class form1 extends JFrame implements ActionListener
{


	JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,
	l10,l11,l12,l13,l14,l15,l16,l17,l18,l19;
	JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14; 
	public JRadioButton rb1,rb2;
	JButton b1,b2;
	ButtonGroup bg;

	public form1()
		{
			setVisible(true);
			setBounds(0,0,2200,1500);
			setTitle("Register Student");
			setLayout(null);
			
			//buttonn group to group 2 radiobuttons
			bg=new ButtonGroup();
				//Labels
			l1=new JLabel("Personal Details");
			l2=new JLabel("Full Name");
			l3=new JLabel("Home Address");
			l4=new JLabel("City");
			l5=new JLabel("State");
			l6=new JLabel("Pincode");
			l7=new JLabel("Phone No.");
			l8=new JLabel("Email id");
			l9=new JLabel("Date of birth");
			l10=new JLabel("Gender");
			l11=new JLabel("Date of Arrival");
			l12=new JLabel("Course");
			l13=new JLabel("Year");
			l14=new JLabel("Familiy Details");
			l15=new JLabel("Father/Guardian Name");
			l16=new JLabel("Occupation");
			l17=new JLabel("Phone no.");
			//to display the format of date onto textfields
			l18=new JLabel("DD/MM/YYYY");
			l19=new JLabel("DD/MM/YYYY");
			
				//textfields to take input
			t1=new JTextField();	
			t2=new JTextField();
			t3=new JTextField();
			t4=new JTextField();
			t5=new JTextField();
			t6=new JTextField();
			t7=new JTextField();
			t8=new JTextField();
			t9=new JTextField();
			t10=new JTextField();
			t11=new JTextField();
			t12=new JTextField();
			t13=new JTextField();
			t14=new JTextField();
						//radio buttons to give check box containing 2 options
			
			rb1=new JRadioButton("Male");
			rb2=new JRadioButton("Female");

			b1=new JButton("Submit");
			b2=new JButton("Home");

			//actionlistenner implementing 
			b1.addActionListener(this);
			b2.addActionListener(this);
			
										//title
										l1.setBounds(200,50,300,60);

			//full name				
			l2.setBounds(50,100,200,40);			t1.setBounds(150,100,350,40);

			//home address
			l3.setBounds(50,150,200,40);			t2.setBounds(150,150,350,40);

					//city&state															state																
					l4.setBounds(120,200,150,40);		t3.setBounds(200,200,190,40);		l5.setBounds(410,200,150,40);			t4.setBounds(460,200,150,40);


					//pincode 															
					l6.setBounds(120,250,150,40);		t5.setBounds(200,250,190,40);


					//phoneno															    //email id
					l7.setBounds(120,300,150,40);		t6.setBounds(200,300,190,40);		l8.setBounds(410,300,150,40);			t7.setBounds(460,300,150,40);

			
			//dob
			l9.setBounds(50,350,200,40);			t8.setBounds(150,350,200,40);   l18.setBounds(170,350,200,40);

			//gender
			l10.setBounds(50,400,200,40);			rb1.setBounds(150,400,100,40);		rb2.setBounds(250,400,100,40);


			//date of arrival
			l11.setBounds(50,450,200,40);			t9.setBounds(150,450,200,40);		l19.setBounds(170,450,200,40);

			//course 	
			l12.setBounds(50,500,200,40);			t10.setBounds(150,500,200,40);		l13.setBounds(410,500,200,40);			t11.setBounds(460,500,200,40);



			

											//Family details
										l14.setBounds(200,610,200,60);			
			//fathr name
			l15.setBounds(50,660,200,40);			t12.setBounds(200,660,350,40);


			//occupation																	
			l16.setBounds(50,710,200,40);			t13.setBounds(150,710,200,40);		


			//phone Number
			l17.setBounds(50,760,200,40);			t14.setBounds(150,760,200,40);
			
			//cancel																	//okay
			b1.setBounds(50,810,200,40);												b2.setBounds(300,810,200,40);
			
			add(l1);
			add(l2);
			add(l3);
			add(l4);
			add(l5);
			add(l6);
			add(l7);
			add(l8);
			add(l9);
			add(l10);
			add(l11);
			add(l12);
			add(l13);
			add(l14);
			add(l15);
			add(l16);
			add(l17);
			add(l18);
			add(l19);
			add(t1);
			add(t2);
			add(t3);
			add(t4);
			add(t5);
			add(t6);
			add(t7);
			add(t8);
			add(t9);
			add(t10);
			add(t11);
			add(t12);
			add(t13);
			add(t14);

			
			add(rb1);
			add(rb2);	
			add (b1);
			add(b2);
			bg.add(rb1);
			bg.add(rb2);


					
		}
		public void actionPerformed(ActionEvent ae)
		{
				if(ae.getSource()==b2)
					{
					new home();
					setVisible(false);
					}
				if(ae.getSource()==b1)
				{
					try
					{
					String a="'"+t1.getText()+"'";
					String b="'"+t2.getText()+"'";
					String c="'"+t3.getText()+"'";
					String d="'"+t4.getText()+"'";
					String e="'"+t5.getText()+"'";
					String f="'"+t6.getText()+"'";
					String g="'"+t7.getText()+"'";
					String h="'"+t8.getText()+"'";
					String i=" ";
						if (rb1.isSelected())
						    i = "Male";
						if (rb2.isSelected())
						    i = "Female";
					String j="'"+t9.getText()+"'";
					String k="'"+t10.getText()+"'";
					String l="'"+t11.getText()+"'";
					String m="'"+t12.getText()+"'";
					String n="'"+t13.getText()+"'";
					String o="'"+t14.getText()+"'";

					

			//step1 Specify driver
					Class.forName("com.mysql.jdbc.Driver");

					//step2 Create connection
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","");

					//step 3
					Statement st=con.createStatement();
					st.executeUpdate("INSERT INTO student_register (full_name, home_address, city, state, pincode, personal_phone, email_id, dob, gender, date_of_arrival, course, year, fathername, occupation, father_phone) VALUES (" + a + "," + b + "," + c + "," + d + "," + e + "," + f + "," + g + "," + h + ",'"+ i +"'," + j + "," + k + "," + l + "," + m + "," + n + "," + o + ")");

					st.close();
					con.close();
					Frame f1=new Frame();
					JOptionPane.showMessageDialog(f1,"Form Filled Succesfully");
					setVisible(false);
					}
					catch(Exception e)
					{
							System.out.println(e);
							Frame f2=new Frame();
					JOptionPane.showMessageDialog(f2,"Eroor!! Please try again");
					}
				}
			}
}
class studform
{
	public static void main(String cp[])
	{
		form1 f1=new form1();
	}
}