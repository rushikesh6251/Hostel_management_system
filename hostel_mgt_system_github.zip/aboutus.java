import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

class form7 extends JFrame implements ActionListener
{
    JLabel l1;
    JTextArea ta1;
    JButton b1;
public void actionPerformed(ActionEvent ae)
        {
            if(ae.getSource()==b1)
                    {
                        new home();
                        setVisible(false);
                    }
        }
    public form7()
    {
        
        setVisible(true);
        setBounds(0, 0, 1000, 800); // Adjusted the size for better visibility
        setTitle("About Us - Hostel Management System");
        setLayout(null);

        // Custom Font
        Font customFont = new Font("Arial", Font.PLAIN, 16);
        b1=new JButton("Home");
        b1.addActionListener(this);
        // Labels
        l1 = new JLabel("About Us");
        l1.setFont(new Font("Arial", Font.BOLD, 24)); // Custom Font for Title

        ta1 = new JTextArea("Introduction:\nWe are Rushikesh Dange and Arpita Murumkar,\n Currently pursuing our BCA degree. " +
                "This project, the Hostel Management System, is the result of our collaboration and enthusiasm.\n\n" +
                "Our Team:\n- Rushikesh Dange- Final-year BCA student\n  Primary developer and coding enthusiast behind the " +
                "project, responsible for coding the Hostel Management System.\n- \n " +
                "  a significant role in documentation and offered valuable insights into system design and functionality.\n\n" +
                "Project Description:\nThe Hostel Management System is designed to streamline and simplify the management " +
                "of hostel facilities. It offers features for room allocation, student records, maintenance tracking, and more.\n\n" +
                "Why This Project:\nWe decided to work on the Hostel Management System because of our shared interest " +
                "in solving real-world problems. The system aims to enhance the hostel living experience for students and administrators.\n\n" +
                "Contact Us:\nrushikesh6251@gmail.com");
        ta1.setFont(customFont);
        ta1.setLineWrap(true);
        ta1.setWrapStyleWord(true);
        ta1.setEditable(false); // Make it read-only
        JScrollPane scrollPane = new JScrollPane(ta1);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        // Title
        l1.setBounds(350, 10, 200, 40);

        // Main Content
        scrollPane.setBounds(50, 60, 800, 600);
        b1.setBounds(350,670,160,60);

        add(l1);
        add(scrollPane);
        add(b1);
        
        
            
    }
}

class aboutus 
{
    public static void main(String cp[])
     {
        form7 f7=new form7();
    }
}


